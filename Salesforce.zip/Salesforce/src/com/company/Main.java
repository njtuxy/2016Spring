package com.company;
import  java.util.Scanner;
import java.util.*;
import java.io.*;

public class Main {

    public static void main(String[] args) {
//        CommandRunner.RunCommand("Dir");
        Dirs dirManager  = new Dirs();

        //Show current dir
        dirManager.mkdir(new Dir("xyz"));
        dirManager.mkdir(new Dir("xxx"));
        dirManager.mkdir(new Dir("xxx"));
        dirManager.mkdir(new Dir("xxxx"));
        dirManager.cd("xxx");
        dirManager.up();
        dirManager.dir();




//        System.out.println(dirs.getCurrentDir().name);



    }


}
