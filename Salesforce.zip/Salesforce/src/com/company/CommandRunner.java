package com.company;

/**
 * Created by yanxia on 2/12/16.
 */
public class CommandRunner {
    Dirs dirs  = new Dirs();

    public  void RunCommand(String command){
    }


    public static void debug(String input){
        System.out.println(input);
    }
}
